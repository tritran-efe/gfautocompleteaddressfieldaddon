// placeholder for javascript
jQuery(document).ready(function($) {

    $('div[name="country_city_auto_addon"]').each(function() {

        const field_id = $(this).attr("id");
        var formid = field_id.substr(6, 1);

        let nameid_1 = $('#' + field_id + ' ' + 'select[id="' + field_id + '_1"]').attr("name");
        $("input[id='customcountry']").removeAttr("name");
        let nameid_2 = $('#' + field_id + ' ' + 'select[id="' + field_id + '_2"]').attr("name");
        $("input[id='customstates']").removeAttr("name");
        let nameid_3 = $('#' + field_id + ' ' + 'select[id="' + field_id + '_3"]').attr("name");
        $("input[id='customcity']").removeAttr("name");
        let nameid_4 = $('#' + field_id + ' ' + 'select[id="' + field_id + '_4"]').attr("name");
        $("input[id='customward']").removeAttr("name");

        function check_input_custom(val, name, id, nameid) {
            if (val == name) {
                $("input[id='" + name + "']").val("")
                $("input[id='" + name + "']").css("display", "block")
                $('#' + field_id + ' ' + 'select[id="' + field_id + '_' + id + '"]').removeAttr("name")
                $("input[id='" + name + "']").attr("name", nameid)
                return true;
            } else {
                $('#' + field_id + ' ' + 'select[id="' + field_id + '_' + id + '"]').attr("name", nameid)
                $("input[id='" + name + "']").removeAttr("name")
                $("input[id='" + name + "']").css("display", "none")
                return false;
            }
        }

        function load_return_select(name, id, nameid) {
            $('#' + field_id + ' ' + 'select[id="' + field_id + '_' + id + '"]').attr("name", nameid)
            $("input[id='" + name + "']").removeAttr("name")
            $("input[id='" + name + "']").css("display", "none")
        }

        function load_select_ward() {
            $('#' + field_id + ' ' + 'table[id="table_form_setting"]' + ' ' + 'tr[id="' + field_id + '_4_container"]').css("display", "table-row");

            $('#' + field_id + ' ' + 'table[id="table_form_setting_above"]' + ' ' + 'tr[id="' + field_id + '_1_container"] td:nth-child(4)').css("display", "table-cell");
            $('#' + field_id + ' ' + 'table[id="table_form_setting_above"]' + ' ' + 'tr[id="' + field_id + '_2_container"] td:nth-child(4)').css("display", "table-cell");

            $('#' + field_id + ' ' + 'table[id="table_form_setting_below"]' + ' ' + 'tr[id="' + field_id + '_1_container"] td:nth-child(4)').css("display", "table-cell");
            $('#' + field_id + ' ' + 'table[id="table_form_setting_below"]' + ' ' + 'tr[id="' + field_id + '_2_container"] td:nth-child(4)').css("display", "table-cell");
        }
        $('#' + field_id + ' ' + 'select[id="' + field_id + '_1"]').change(function() {
            let country = $('select[id="' + field_id + '_1"] option:selected').val();
            let datacustominput = $('select[id="' + field_id + '_1"]').attr("data-custom-input");
            let check_input_1 = check_input_custom(country, "customcountry", 1, nameid_1);
            if (check_input_1 == false) {
                if ($('select[id="' + field_id + '_1"] option[name="country_input_placeholders"]').length != 0) {
                    $('select[id="' + field_id + '_1"] option[name="country_input_placeholders"]').remove();
                }

                $('select[id="' + field_id + '_1"] option[name="placeholder"]').remove();
                $('#' + field_id + ' ' + '.loader').fadeIn();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: 'get',
                    url: ajax_object.ajaxurl,
                    data: {
                        action: 'Ajax_GF_Field_country',
                        country: country,
                        datacustominput: datacustominput,
                    },
                    dataType: 'json',
                    cache: false,
                    success: function(data) {
                        $('#' + field_id + ' ' + 'select[id="' + field_id + '_2"]').html(data[0]);
                        if (datacustominput == true) {
                            $('#' + field_id + ' ' + 'select[id="' + field_id + '_3"]').html("<option value=''>Choose the city</option><option value='customcity'>Custom City</option>");
                            $('#' + field_id + ' ' + 'select[id="' + field_id + '_4"]').html("<option value=''>Choose the ward</option><option value='customward'>Custom Ward</option>");
                        } else {
                            $('#' + field_id + ' ' + 'select[id="' + field_id + '_3"]').html("<option value=''>Choose the city</option>");
                            $('#' + field_id + ' ' + 'select[id="' + field_id + '_4"]').html("<option value=''>Choose the ward</option>");
                        }

                        if (data[1] == true) {
                            load_select_ward()
                        } else {
                            $('#' + field_id + ' ' + 'table[id="table_form_setting_above"]' + ' ' + 'tr[id="' + field_id + '_1_container"] td:nth-child(4)').css("display", "none");
                            $('#' + field_id + ' ' + 'table[id="table_form_setting_above"]' + ' ' + 'tr[id="' + field_id + '_2_container"] td:nth-child(4)').css("display", "none");

                            $('#' + field_id + ' ' + 'table[id="table_form_setting_below"]' + ' ' + 'tr[id="' + field_id + '_1_container"] td:nth-child(4)').css("display", "none");
                            $('#' + field_id + ' ' + 'table[id="table_form_setting_below"]' + ' ' + 'tr[id="' + field_id + '_2_container"] td:nth-child(4)').css("display", "none");

                            $('#' + field_id + ' ' + 'table[id="table_form_setting"]' + ' ' + 'tr[id="' + field_id + '_4_container"]').css("display", "none");
                        }
                        $('#' + field_id + ' ' + '.loader').fadeOut();
                        load_return_select("customstates", 2, nameid_2)
                        load_return_select("customcity", 3, nameid_3)
                        load_return_select("customward", 4, nameid_4)
                    }
                });
            } else {
                $('#' + field_id + ' ' + 'select[id="' + field_id + '_2"]').html("<option value=''>Choose the states</option><option value='customstates'>Custom States</option>");
                $('#' + field_id + ' ' + 'select[id="' + field_id + '_3"]').html("<option value=''>Choose the city</option><option value='customcity'>Custom City</option>");
                $('#' + field_id + ' ' + 'select[id="' + field_id + '_4"]').html("<option value=''>Choose the ward</option><option value='customward'>Custom Ward</option>");
                load_select_ward()
            }
        })

        $('#' + field_id + ' ' + 'select[id="' + field_id + '_2"]').change(function() {
            let states = $('select[id="' + field_id + '_2"] option:selected').val();
            let datacustominput = $('select[id="' + field_id + '_2"]').attr("data-custom-input");
            let check_input_2 = check_input_custom(states, "customstates", 2, nameid_2);
            if (check_input_2 == false) {
                if ($('select[id="' + field_id + '_2"] option[name="states_input_placeholders"]').length != 0) {
                    $('select[id="' + field_id + '_2"] option[name="states_input_placeholders"]').remove();
                }
                $('select[id="' + field_id + '_2"] option[name="placeholder"]').remove();
                $('#' + field_id + ' ' + '.loader').fadeIn();

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: 'get',
                    url: ajax_object.ajaxurl,
                    data: {
                        action: 'Ajax_GF_Field_states',
                        states: states,
                        datacustominput: datacustominput,
                    },
                    dataType: 'json',
                    cache: false,
                    success: function(data) {
                        $('#' + field_id + ' ' + 'select[id="' + field_id + '_3"]').html(data[0]);
                        if (datacustominput == true) {
                            $('#' + field_id + ' ' + 'select[id="' + field_id + '_4"]').html("<option value=''>Choose the ward</option><option value='customward'>Custom Ward</option>");
                        } else {
                            $('#' + field_id + ' ' + 'select[id="' + field_id + '_4"]').html("<option value=''>Choose the ward</option>");
                        }
                        $('#' + field_id + ' ' + '.loader').fadeOut();
                        load_return_select("customcity", 3, nameid_3)
                        load_return_select("customward", 4, nameid_4)
                    }
                });
            } else {
                $('#' + field_id + ' ' + 'select[id="' + field_id + '_3"]').html("<option value=''>Choose the city</option><option value='customcity'>Custom City</option>");
                $('#' + field_id + ' ' + 'select[id="' + field_id + '_4"]').html("<option value=''>Choose the ward</option><option value='customward'>Custom Ward</option>");
                load_select_ward()
            }
        })



        $('#' + field_id + ' ' + 'select[id="' + field_id + '_3"]').change(function() {
            let city = $('select[id="' + field_id + '_3"] option:selected').val();
            let datacustominput = $('select[id="' + field_id + '_3"]').attr("data-custom-input");
            let check_input_3 = check_input_custom(city, "customcity", 3, nameid_3);
            if (check_input_3 == false) {
                if ($('#' + field_id + ' ' + 'tr[id="' + field_id + '_4_container"]').is(":visible")) {
                    if ($('select[id="' + field_id + '_3"] option[name="states_input_placeholders"]').length != 0) {
                        $('select[id="' + field_id + '_3"] option[name="states_input_placeholders"]').remove();
                    }
                    $('select[id="' + field_id + '_3"] option[name="placeholder"]').remove();
                    $('#' + field_id + ' ' + '.loader').fadeIn();
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: 'get',
                        url: ajax_object.ajaxurl,
                        data: {
                            action: 'Ajax_GF_Field_city',
                            city: city,
                            datacustominput: datacustominput,
                        },
                        dataType: 'json',
                        cache: false,
                        success: function(data) {
                            $('#' + field_id + ' ' + 'select[id="' + field_id + '_4"]').html(data[0]);
                            $('#' + field_id + ' ' + '.loader').fadeOut();
                            load_return_select("customward", 4, nameid_4)
                        }
                    });
                }
            } else {
                $('#' + field_id + ' ' + 'select[id="' + field_id + '_4"]').html("<option value=''>Choose the ward</option><option value='customward'>Custom Ward</option>");
                load_select_ward()
            }
        })

        $('#' + field_id + ' ' + 'select[id="' + field_id + '_4"]').change(function() {
            var ward = $('select[id="' + field_id + '_4"] option:selected').val();
            check_input_custom(ward, "customward", 4, nameid_4);
        })
    })
})
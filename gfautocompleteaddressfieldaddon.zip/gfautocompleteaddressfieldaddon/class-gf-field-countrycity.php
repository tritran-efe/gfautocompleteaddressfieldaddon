<?php
    GFForms::include_addon_framework();

    class GFCountrycityFieldAddOn extends GFAddOn{
        protected $_version = GF_AUTO_COUNTRYCITY_FIELD_ADDON_VERSION;
        protected $_min_gravityforms_version = '1.0';
        protected $_slug = 'autocompletecountrycityfieldaddon';
        protected $_path = 'gfautocompleteaddressfieldaddon/gfautocompleteaddressfieldaddon.php';
        protected $_full_path = __FILE__;
        protected $_title = 'Gravityforms Auto Populate Country/State/City/Ward DropDown Addon';
        protected $_short_title = 'Automatic Country/City Field Add-On';

        private static $_instance = null;

        public static function get_instance() {
            if ( self::$_instance == null ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }
        
        public function pre_init() {
            parent::pre_init();
    
            if ( $this->is_gravityforms_supported() && class_exists( 'GF_Field' ) ) {
                require_once( plugin_dir_path( __FILE__ ) . 'includes/class-gffield-countrycity.php' );
                require_once( plugin_dir_path( __FILE__ ) . 'includes/ajax.php' );
                add_action( 'gform_enqueue_scripts', array($this,'addon_CTCT_pre_init_enqueue_script'));
                add_action( 'gform_editor_js', array( $this,"input_placeholders_gform_editor_js"));
                add_action( 'gform_editor_js_set_default_values' , array( $this,'class_gffield_countrycity_group' ));

            }
        }

        public function init_admin() {
            parent::init_admin();
            add_action( 'admin_enqueue_scripts', array($this,'addon_CTCT_init_admin_enqueue_script'));
            add_action( 'gform_editor_js', array( $this,"input_placeholders_gform_editor_js"));
            add_filter( 'gform_enable_field_label_visibility_settings', '__return_true' );
            // add_filter( 'gform_init_scripts_footer', '__return_true' );
            add_filter( 'gform_tooltips', array( $this, 'tooltips' ) );
            add_action( 'gform_field_advanced_settings', array( $this, 'field_advanced_settings' ), 10, 2 );
            // add_filter( 'gform_pre_render', array( $this, 'populate_choices' ));
            add_filter( 'gform_admin_pre_render', array( $this, 'populate_choices' ));
            }

        public function scripts() {
            $scripts = array(
                array(
                    'handle'   => 'countrycity_addon_script_js',
                    // 'src'      => $this->get_base_url() . '/js/fields.js',
                    'version'  => $this->_version,
                    'deps'     => array( 'jquery' ),
                    'callback' => array( $this, 'localize_scripts' ),
                    'enqueue'  => array(
                        array( 'field_types' => array( 'countrycity' ) ),
                    ),
                ),
            );
            return array_merge( parent::scripts(), $scripts );
        }

        public function styles() {
            $styles = array(
                array(
                        'handle'  => 'countrycity_addon_styles',
                        'src'     => $this->get_base_url() . '/css/admin.css',
                        'version' => $this->_version,
                        'enqueue' => array(
                            array( 'field_types' => array( 'countrycity' ) )
                        )
                    ),
                array(
                        'handle'  => 'countrycity_addon_styles_font-end',
                        'src'     => $this->get_base_url() . '/css/font-end.css',
                        'version' => $this->_version,
                        'enqueue' => array(
                            array( 'field_types' => array( 'countrycity' ) )
                        )
                    )
            );
            return array_merge( parent::styles(), $styles );
        }
        
        public function tooltips( $tooltips ) {
            $simple_tooltips = array(
                'default_value_setting' => sprintf( '<h6>%s</h6>%s', esc_html__( 'Default Country', 'countrycityfieldaddon' ), esc_html__( 'If you would like to pre-populate the value of a field, enter it here.', 'countrycityfieldaddon' ) ),
            );
            return array_merge( $tooltips, $simple_tooltips );
        }

        public function field_advanced_settings( $position, $form_id ) {
            if ( $position == 200 ) {
                ?>
                <li class="input_class_setting field_setting">
                    <label for="field_default_value" class="section_label">
                        <?php esc_html_e( 'Default Country', 'countrycityfieldaddon' ); ?>
                        <?php gform_tooltip( 'default_value_setting' ) ?>
                    </label>
                    <select id="field_default_value" class="field_default_value fieldwidth-2 merge-tag-support mt-position-right mt-prepopulate ui-autocomplete-input">
                    </select>
                </li>
                <?php
            }
        }

        public function populate_choices( $form ) {
            $json = file_get_contents(plugin_dir_path( __FILE__ ) . 'data/countries+states+cities.json');
            $json_data = json_decode($json,true);
            $boo = false;
            foreach ( $form['fields'] as $field ) {
                if ( $field->type == "countrycity" ) {
                    $field->choices = array();
                    foreach ($json_data as $value){
                        $choices1 = array("text" => $value['name'],
                        "value" => $value['name'],
                        "isSelected" => "",
                        "price" => "",);
                        array_push($field->choices,$choices1);
                    }
                }
            }
            return $form;
        }
        public function addon_CTCT_pre_init_enqueue_script() {
            wp_enqueue_script( 'addon_CTCT_pre_init_enqueue_script-handle');
            wp_register_script( 'addon_CTCT_pre_init_enqueue_script-handle', plugin_dir_url( __FILE__ ) . 'js/admin.js', array('jquery'), '', true );
            wp_localize_script( 'addon_CTCT_pre_init_enqueue_script-handle','ajax_object',array('ajaxurl' => admin_url('admin-ajax.php') ));
        }
        public function addon_CTCT_init_admin_enqueue_script(){
            wp_register_style( 'addon_CTCT_init_admin_enqueue_script-handle2-1', plugin_dir_url( __FILE__ ) . 'css/admin.css', array(), 1, 'all' );
            wp_enqueue_style( 'addon_CTCT_init_admin_enqueue_script-handle2-1');
        }
        public function class_gffield_countrycity_group(){
            ?>
                case 'countrycity' : field.inputType = 'countrycity';
                field.inputs = new Array();
                field.inputs.push(new Input(field.id + '.1', '<?php echo apply_filters( 'gform_name_country_' . rgget( 'id' ), apply_filters( 'gform_name_country', __( 'Country', 'gravityforms' ), rgget( 'id' ) ), rgget( 'id' ) ); ?>'));
                field.inputs.push(new Input(field.id + '.2', '<?php echo apply_filters( 'gform_name_states_' . rgget( 'id' ), apply_filters( 'gform_name_states', __( 'States', 'gravityforms' ), rgget( 'id' ) ), rgget( 'id' ) ); ?>'));
                field.inputs.push(new Input(field.id + '.3', '<?php echo apply_filters( 'gform_name_city_' . rgget( 'id' ), apply_filters( 'gform_name_city', __( 'City', 'gravityforms' ), rgget( 'id' ) ), rgget( 'id' ) ); ?>'));
                field.inputs.push(new Input(field.id + '.4', '<?php echo apply_filters( 'gform_name_ward_' . rgget( 'id' ), apply_filters( 'gform_name_ward', __( 'Ward', 'gravityforms' ), rgget( 'id' ) ), rgget( 'id' ) ); ?>'));
                break;
            <?php
        }

        public function input_placeholders_gform_editor_js(){
            ?>
            <script>
                jQuery(document).on("gform_load_field_settings", function(event, field, form){
                    var fieldid = field["id"], formid = form['id'];
                    var ojfield = GetFieldById(fieldid);
                    
                    if(ojfield.type == "countrycity"){

                        // jQuery(".prepopulate_field_setting.field_setting label").contents().first()[0].textContent = 'Allow Field To Be Populated Dynamically ';
                        
                        //description
                        jQuery("#field_description").keyup(function(){
                            jQuery("#gfield_description_"+formid+"_"+fieldid).text(jQuery(this).val());
                        })

                        for(var i = 1 ; i <=field.inputs.length ; i++){
                            sublabel(i)
                            placeholder(i)
                        }
                        //sub label input
                        function sublabel(i){
                            jQuery("input[id='field_custom_input_label_"+fieldid+"."+i+"']").keyup(function(){
                                var string = jQuery(this).val();
                                var place = jQuery(this).attr('placeholder');
                                if(string != ""){
                                    jQuery("label[id='input_"+fieldid+"_"+i+"_label'] strong").text(string);
                                }else{
                                    jQuery("label[id='input_"+fieldid+"_"+i+"_label'] strong").text(place);
                                }
                            });
                        }
                        //placeholder
                        function placeholder(i){
                            jQuery("tr.input_placeholder_row[data-input_id='"+fieldid+"."+i+"'] input").keyup(function(){
                                var string = jQuery(this).val();
                                if(string != ""){
                                    if(jQuery("#input_"+fieldid+"_"+i+" option[name='country_input_placeholders']").length == 0){
                                        jQuery("#input_"+fieldid+"_"+i+"").append("<option name='country_input_placeholders' value='"+string+"' selected>"+string+"</option>")
                                    }else{
                                        jQuery("#input_"+fieldid+"_"+i+" option[name='country_input_placeholders']").text(string)
                                    }
                                }else{
                                    jQuery("#input_"+fieldid+"_"+i+" option[name='country_input_placeholders']").remove();
                                }
                            });
                        }
                        load_default_unique_group_value()
                        //defaultValue && uniqueValue && EnableGroupValue
                        function load_default_unique_group_value(){
                            jQuery("select[id='field_default_value']").prop( "disabled", true );
                            var defaultValueText = field['defaultValue'];
                            var defaultValue = "";
                            defaultValue += '<option value="">Choose a default value</option>';

                            jQuery.getJSON("../wp-content/plugins/gfautocompleteaddressfieldaddon/data/countries+states+cities.json?nocache="+(new Date()).getTime(), function(data){
                                jQuery.each( data, function( key, value ) {
                                    if(defaultValueText == value.name){
                                        defaultValue += '<option selected value="'+value.name+'">'+value.name+'</option>';
                                    }else{
                                        defaultValue += '<option value="'+value.name+'">'+value.name+'</option>';
                                    }
                                })
                                jQuery("select[id='field_default_value']").html(defaultValue);
                                jQuery("select[id='field_default_value']").prop( "disabled", false );
                            });
                        }
                    }
                    
                    //Conditional logic
                    conditional(event, field, form)
                    loadevent()
                    function loadevent(){
                        jQuery(".gf_conditional_logic_rules_container").each(function(index){
                            jQuery(jQuery(this).find(':nth-child(4)')).on( "click", jQuery(this), function() {
                                InsertRule("field",(index+1))
                                loadevent()
                                conditional(event, field, form)
                            });
                            jQuery(jQuery(this).find(':nth-child(5)')).on( "click", jQuery(this), function() {
                                DeleteRule("field",(index))
                                loadevent()
                                conditional(event, field, form)
                            });
                        })
                    }
                })

                function conditional(event, field, form){
                    var default_states = "";
                    jQuery(".gf_conditional_logic_rules_container").each(function(index){
                        var field_x11 = jQuery("#field_rule_field_"+index).val();
                        var field_x21 = field_x11.substr(0,1);
                        var field_x31 = GetFieldById(field_x21);
                        if(field_x31.type == "countrycity"){
                            var field_y11 = field_x31.inputs;
                            var field_y21 = field_y11[0].id;
                            var field_y31 = field_y11[1].id;
                            var field_y41 = field_y11[2].id;
                            if(field_x11 == field_y41){
                                default_city =  jQuery("#field_rule_value_"+index).val();
                                jQuery("#field_rule_value_"+index).addClass("city_conditionlogic");
                                jQuery(".city_conditionlogic").html(' ');
                                jQuery(jQuery(this).find('.city_conditionlogic')).append('<option value="">Choose the city</option>');
                                loadcity(index,default_city,jQuery(this))
                            }
                            //setting Unique Value
                            if(field_x31.uniqueValue){
                                if(field_x11 == field_y21){
                                    jQuery("#field_rule_value_"+index).html("<option value='"+field_x31.uniqueValue+"'>"+field_x31.uniqueValue+"</option>");
                                }
                            }
                            //
                        }
                    })
                    jQuery(".gf_conditional_logic_rules_container").each(function(index){
                        // var child = jQuery(this);
                        jQuery('a[class="add_field_choice"]').attr("onclick","");
                        jQuery('a[class="delete_field_choice"]').attr("onclick","");

                        var field_x1 = jQuery("#field_rule_field_"+index).val();
                        var field_x2 = field_x1.substr(0,1);
                        var field_x3 = GetFieldById(field_x2);

                        var value_x1 = jQuery("#field_rule_value_"+index).val();

                        if(field_x3.type == "countrycity"){
                            var field_y1 = field_x3.inputs;
                            var field_y2 = field_y1[0].id;
                            var field_y3 = field_y1[1].id;
                            var field_y4 = field_y1[2].id;
                            var default_states = "";
                            
                            if(field_x1 == field_y3){
                                default_states =  jQuery("#field_rule_value_"+index).val();
                                jQuery("#field_rule_value_"+index).addClass("states_conditionlogic");
                                jQuery(".states_conditionlogic").html(' ');
                                jQuery(".states_conditionlogic").append('<option value="">Choose the city</option>');
                                loadstates(index,default_states)
                            }
                        }

                        

                        jQuery("#field_rule_field_"+index).change(function(){
                            
                            var input_id = jQuery(this).val();
                            var field_id = jQuery(this).val().substr(0,1);
                            var a = GetFieldById(field_id);
                            if(a.type == "countrycity"){
                                var b = a.inputs;
                                var c = b[0].id;
                                var d = b[1].id;
                                var e = b[2].id;
                                if(input_id == c){
                                    jQuery("#field_rule_value_"+index).removeClass("states_conditionlogic");
                                    loadstates(null,null);
                                    loadcity(null,null,null);
                                    loadcountry();
                                }
                                if(input_id == d){
                                    jQuery("#field_rule_value_"+index).addClass("states_conditionlogic");
                                    jQuery(".states_conditionlogic").html(' ');
                                    jQuery(".states_conditionlogic").append('<option value="">Choose the city</option>');
                                    loadstates(null,null);
                                    jQuery(".city_conditionlogic").html(' ');
                                    jQuery(".city_conditionlogic").append('<option value="">Choose the city</option>');
                                    loadcity(null,null,null);
                                }
                                if(input_id == e){
                                    jQuery("#field_rule_value_"+index).addClass("city_conditionlogic");
                                    jQuery(".city_conditionlogic").html(' ');
                                    jQuery(".city_conditionlogic").append('<option value="">Choose the city</option>');
                                    loadcity(null,null,null);
                                }
                            }
                        })

                        jQuery("#field_rule_value_"+index).change(function(){
                            var input_id = jQuery("#field_rule_field_"+index).val();
                            var field_id = jQuery("#field_rule_field_"+index).val().substr(0,1);
                            var a = GetFieldById(field_id);
                            if(a.type == "countrycity"){
                                var b = a.inputs;
                                var c = b[0].id;
                                var d = b[1].id;
                                if(input_id == c){
                                    jQuery(".states_conditionlogic").html(' ');
                                    jQuery(".states_conditionlogic").append('<option value="">Choose the states</option>');
                                    loadstates(null,null);
                                }
                                if(input_id == d){
                                    jQuery(".city_conditionlogic").html(' ');
                                    jQuery(".city_conditionlogic").append('<option value="">Choose the city</option>');
                                    loadcity(null,null,null);
                                }
                            }
                        })
                    })
                        function loadcountry(){
                            jQuery("#field_rule_value_"+index).html(" ");
                            jQuery.getJSON("../wp-content/plugins/gfautocompleteaddressfieldaddon/data/countries+states+cities.json", function(data){
                                jQuery.each( data, function( key, value ) {
                                    jQuery("#field_rule_value_"+index).append('<option value="'+value.name+'">'+value.name+'</option>');
                                });
                            });
                        }

                        function loadstates(index_1,default_states){
                            var arr = new Array();
                            jQuery(".gf_conditional_logic_rules_container").each(function(index2){
                                var field_x1 = jQuery("#field_rule_field_"+index2).val();
                                var field_x2 = field_x1.substr(0,1);
                                var field_x3 = GetFieldById(field_x2);
                                var field_y1 = field_x3.inputs;
                                var field_y2 = field_y1[0].id;
                                var field_y3 = field_y1[1].id;
                                if(field_x1 == field_y2 ){
                                    arr.push(jQuery("#field_rule_value_"+index2).val());
                                }
                            })
                            var uniqueStates = new Array();
                            jQuery.each(arr, function(i, el){
                                if(jQuery.inArray(el, uniqueStates) === -1) uniqueStates.push(el);
                            });

                            jQuery.each(uniqueStates,function(key,value){
                                var val = value;
                                jQuery.getJSON("../wp-content/plugins/gfautocompleteaddressfieldaddon/data/countries+states+cities.json", function(data){
                                    jQuery.each( data, function( key, value1 ) {
                                        if(value1.name == val){
                                            var z = value1.states;
                                            jQuery.each(z,function( key, value2 ){
                                                if(default_states == value2.name){
                                                    jQuery("#field_rule_value_"+index_1).append('<option selected value="'+value2.name+'">'+value2.name+'</option>');
                                                    return true;
                                                }
                                                jQuery(".states_conditionlogic").append('<option value="'+value2.name+'">'+value2.name+'</option>')
                                            })
                                        }
                                    });
                                });
                            })
                        }
                        function loadcity(index_2,default_city,tol_this){
                            var states = new Array();
                            var city = new Array();
                            jQuery(".gf_conditional_logic_rules_container").each(function(index3){
                                var field_a1 = jQuery("#field_rule_field_"+index3).val();
                                var field_a2 = field_a1.substr(0,1);
                                var field_a3 = GetFieldById(field_a2);
                                var field_b1 = field_a3.inputs;
                                var field_b2 = field_b1[0].id;
                                var field_b3 = field_b1[1].id;
                                var field_b4 = field_b1[2].id;
                                if(field_a1 == field_b2 ){
                                    states.push(jQuery("#field_rule_value_"+index3).val());
                                }
                                if(field_a1 == field_b3 ){
                                    city.push(jQuery("#field_rule_value_"+index3).val());
                                }
                            })
                            var uniqueStates = new Array();
                            jQuery.each(states, function(i, el){
                                if(jQuery.inArray(el, uniqueStates) === -1) uniqueStates.push(el);
                            });
                            var uniqueCity = new Array();
                            jQuery.each(city, function(i, el){
                                if(jQuery.inArray(el, uniqueCity) === -1) uniqueCity.push(el);
                            });

                            jQuery.each(uniqueStates,function(key,valueStates){
                                jQuery.getJSON("../wp-content/plugins/gfautocompleteaddressfieldaddon/data/countries+states+cities.json", function(data){
                                    jQuery.each( data, function( key, value1 ) {
                                        if(valueStates == value1.name){
                                            jQuery.each(value1.states,function( key, value2 ){
                                                jQuery.each(uniqueCity,function(key,valueCity){
                                                    if(valueCity == value2.name){
                                                        jQuery.each(value2.cities,function(key, value3){
                                                            if(default_city == value3.name){
                                                                jQuery("#field_rule_value_"+index_2).append('<option selected value="'+value3.name+'">'+value3.name+'</option>');
                                                                return true;
                                                            }
                                                            if(tol_this != null){
                                                                jQuery(tol_this.find('.city_conditionlogic')).append('<option value="'+value3.name+'">'+value3.name+'</option>')
                                                            }else{
                                                                jQuery(".city_conditionlogic").append('<option value="'+value3.name+'">'+value3.name+'</option>')
                                                            }
                                                        })
                                                    }
                                                })
                                            })
                                        }
                                    });
                                });
                            })
                        }
                }
            </script>
            <?php
        }
    }
    GFAddOn::register( 'GFCountrycityFieldAddOn' );
?>
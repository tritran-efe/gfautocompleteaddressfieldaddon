<?php
    /*
    Plugin Name: Auto Populate Country/State/City/Ward DropDown Addon for Gravity Forms
    Plugin URI: https://gravityextra.com/
    Description: City dropdown automatically be populated based on the selected Country.
    Version: 1.0
    Author: Gravity Extra
    Author URI: http://efe.com.vn/
    */
    define( 'GF_AUTO_COUNTRYCITY_FIELD_ADDON_VERSION', '1.0' );

    add_action( 'gform_loaded', array( 'GF_Auto_Countrycity_Field_AddOn', 'load' ), 5 );

    class GF_Auto_Countrycity_Field_AddOn {
        public static function load() {
            if ( ! method_exists( 'GFForms', 'include_addon_framework' ) ) {
                return;
            }
            require_once( 'class-gf-field-countrycity.php' );
        }
    }
?>

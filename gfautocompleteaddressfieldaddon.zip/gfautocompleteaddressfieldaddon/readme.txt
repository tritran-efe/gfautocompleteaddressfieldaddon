=== Plugin Name ===

Contributors: EFE Technology
Plugin Name: Auto Populate Country/State/City/Ward DropDown Addon for Gravity Forms
Plugin URI: https://gravityextra.com/
Tags: gravity forms,forms
Author URI: http://efe.com.vn/
Author: Gravity Extra
Donate link: http://efe.com.vn
Requires at least: 4.0
Tested up to: 
Stable tag: 1.0
Version: 1.0
License: GPLv2 or later

== Description ==

(https://gravityextra.com/)

Easily select the national city automatically.
If you have order pages, this addon will facilitate the user to choose the address.

== Screenshots ==

1.Users are easy to choose city national information.

== Installation ==

== Upgrade Notice ==

== Changelog ==

== Frequently Asked Questions ==

== Donations ==
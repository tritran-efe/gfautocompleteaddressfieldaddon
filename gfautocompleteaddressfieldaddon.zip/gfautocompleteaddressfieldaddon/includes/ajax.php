<?php
    class GF_Auto_Countrycity_Field_Ajax{
        function __construct(){
            add_action( 'wp_ajax_Ajax_GF_Field_country', array( $this, 'Ajax_GF_Field_Auto_Country'));
            add_action('wp_ajax_nopriv_Ajax_GF_Field_country', array( $this, 'Ajax_GF_Field_Auto_Country'));
            add_action( 'wp_ajax_Ajax_GF_Field_states', array( $this, 'Ajax_GF_Field_Auto_States'));
            add_action('wp_ajax_nopriv_Ajax_GF_Field_states', array( $this, 'Ajax_GF_Field_Auto_States'));
            add_action( 'wp_ajax_Ajax_GF_Field_city', array( $this, 'Ajax_GF_Field_Auto_City'));
            add_action('wp_ajax_nopriv_Ajax_GF_Field_city', array( $this, 'Ajax_GF_Field_Auto_City'));
            // Enable Group Value
            add_action( 'wp_ajax_Ajax_GF_Field_Add_Value', array( $this, 'Ajax_GF_Field_Add_Value'));
            add_action('wp_ajax_nopriv_Ajax_GF_Field_Add_Value', array( $this, 'Ajax_GF_Field_Add_Value'));
        }
        function Ajax_GF_Field_Auto_Country(){
            $country_request = $_GET['country'];
            $datacustominput = $_GET['datacustominput'];
            $request = wp_remote_get( plugin_dir_url( __DIR__ ). 'data/countries+states+cities.json');
            $country = wp_remote_retrieve_body($request);
            $country_1 =json_decode($country, TRUE);
            ksort($country_1);

            $states_option = "";
            $states_option .= "<option value=''>Choose the states</option>";
            $bolean = false;
            $arr = array();
            foreach($country_1 as $key_country => $val_country){
                if($val_country['name'] === $country_request){
                    foreach($val_country['states'] as $key_states => $val_states){
                        $states_option .= "<option value='{$val_states['name']}'>{$val_states['name']}</option>";
                        foreach($val_states['cities'] as $key_city => $val_city){
                            if(count($val_city['ward'])>0){
                                $bolean = true;
                                break;
                            }
                        }
                    }
                    break;
                }
            }
            if($datacustominput == true){
                $states_option .= "<option value='customstates'>Custom States</option>";
            }
            array_push($arr,$states_option);
            array_push($arr,$bolean);
            echo json_encode($arr);
            // echo $states_option;
            wp_die();
        }
        function Ajax_GF_Field_Auto_States(){
            $states_request = $_GET['states'];
            $datacustominput = $_GET['datacustominput'];
            $request = wp_remote_get( plugin_dir_url( __DIR__ ). 'data/countries+states+cities.json');
            $country = wp_remote_retrieve_body($request);
            $country_1 =json_decode($country, TRUE);
            ksort($country_1);

            $city_option = "";
            $city_option .= "<option value=''>Choose the city</option>";
            $bolean = false;
            $arr = array();
            foreach($country_1 as $key_country => $val_country){
                    foreach($val_country['states'] as $key_states => $val_states){
                        if($val_states['name'] == $states_request){
                            foreach($val_states['cities'] as $key_city => $val_city){
                                $city_option .= "<option value='{$val_city['name']}'>{$val_city['name']}</option>";
                            }
                            foreach($val_states['cities'] as $key_city => $val_city){
                                if(array_key_exists('ward', $val_city)){
                                    if(count($val_city['ward'])>0){
                                        $bolean = true;
                                        break;
                                    }
                                }
                            }
                            break;
                        }
                    }
            }
            if($datacustominput == true){
                $city_option .= "<option value='customcity'>Custom City</option>";
            }
            array_push($arr,$city_option);
            array_push($arr,$bolean);
            echo json_encode($arr);
            // echo $city_option;
            wp_die();
        }
        function Ajax_GF_Field_Auto_City(){
            $city_request = $_GET['city'];
            $datacustominput = $_GET['datacustominput'];
            $request = wp_remote_get( plugin_dir_url( __DIR__ ). 'data/countries+states+cities.json');
            $country = wp_remote_retrieve_body($request);
            $country_1 =json_decode($country, TRUE);
            ksort($country_1);

            $ward_option = "";
            $ward_option .= "<option value=''>Choose the ward</option>";
            $bolean = false;
            $arr = array();
            foreach($country_1 as $key_country => $val_country){
                foreach($val_country['states'] as $key_states => $val_states){
                    foreach($val_states['cities'] as $key_city => $val_city){
                        if(array_key_exists('ward', $val_city)){
                            if(count($val_city['ward'])>0){
                                $bolean = true;
                            }
                        }
                    }
                    foreach($val_states['cities'] as $key_city => $val_city){
                        if($val_city['name'] == $city_request){
                            foreach($val_city['ward'] as $val_ward){
                                $ward_option .= "<option value='{$val_ward['name']}'>{$val_ward['name']}</option>";
                            }
                            break;
                        }
                    }
                }
            }
            if($datacustominput == true){
                $ward_option .= "<option value='customward'>Custom Ward</option>";
            }
            array_push($arr,$ward_option);
            array_push($arr,$bolean);
            echo json_encode($arr);
            wp_die();
        }

        function Ajax_GF_Field_Add_Value(){
            $key = $_GET['key'];
            $country = $_GET['country'];
            $country = str_replace("\\","",$country);
            $states = $_GET['states'];
            $city = $_GET['city'];

            $country_input = ucfirst($_GET['country_input']);
            $country_input = preg_replace("/[^A-Za-z' ]/", "", $country_input);
            $iso2_input = $_GET['iso2_input'];
            $states_input = ucfirst($_GET['states_input']);
            $states_input = preg_replace("/[^A-Za-z' ]/", "", $states_input);
            $city_input = ucfirst($_GET['city_input']);
            $city_input = preg_replace("/[^A-Za-z' ]/", "", $city_input);


            $json = file_get_contents(plugin_dir_url( __DIR__ ) . 'data/countries+states+cities.json');
            $json_data = json_decode($json,true);

            if($key == "add_country"){
                $id = "";
                foreach ($json_data as $value) {
                    if($value['id'] > $id){
                        $id = $value['id'];
                    }
                }
                $json_data[] = array('id'=> ($id+1), 'name'=>$country_input, 'iso2'=>$iso2_input, 'states'=> []);
            }
            if($key == "add_states"){
                $arr_states = array('name' => $states_input, 'cities'=>[]);
                foreach ($json_data as $key => $value) {
                    if($value['name'] == $country){
                        $json_data[$key]['states'][] = $arr_states;
                        break;
                    }
                }
            }
            if($key == "add_city"){
                $arr_city = array('name' => $city_input);
                foreach ($json_data as $key => $value) {
                    if($value['name'] == $country){
                        foreach($value['states'] as $key2 => $value2){
                            if($value2['name'] == $states){
                                $json_data[$key]['states'][$key2]['cities'][] = $arr_city;
                                break;
                            }
                        }
                    }
                }
            }
            if($key == "edit_country"){
                foreach ($json_data as $key => $value) {
                    if ($value['name'] == $country) {
                        $json_data[$key]['name'] = $country_input;
                        break;
                    }
                }
            }
            if($key == "edit_states"){
                foreach ($json_data as $key => $value) {
                    if ($value['name'] == $country) {
                        foreach($value['states'] as $key2 => $value2){
                            if($value2['name'] == $states){
                                $json_data[$key]['states'][$key2]['name'] = $states_input;
                                break;
                            }
                        }
                    }
                }
            }
            if($key == "edit_city"){
                foreach ($json_data as $key => $value) {
                    if ($value['name'] == $country) {
                        foreach($value['states'] as $key2 => $value2){
                            if($value2['name'] == $states){
                                foreach($value2['cities'] as $key3 => $value3){
                                    if($value3['name'] == $city){
                                        $json_data[$key]['states'][$key2]['cities'][$key3]['name'] = $city_input;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if($key == "delete_country"){
                foreach($json_data as $key => $value){
                    if($value['name'] == $country){
                        unset($json_data[$key]);
                        break;
                    }
                }
            }
            if($key == "delete_states"){
                foreach($json_data as $key => $value){
                    if($value['name'] == $country){
                        foreach($value['states'] as $key2 => $value2){
                            if($value2['name'] == $states){
                                unset($json_data[$key]['states'][$key2]);
                                break;
                            }
                        }
                    }
                }
            }
            if($key == "delete_city"){
                foreach($json_data as $key => $value){
                    if($value['name'] == $country){
                        foreach($value['states'] as $key2 => $value2){
                            if($value2['name'] == $states){
                                foreach($value2['cities'] as $key3 => $value3){
                                    if ($value3['name'] == $city) {
                                        unset($json_data[$key]['states'][$key2]['cities'][$key3]);
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            file_put_contents(plugin_dir_path( __DIR__ ) . 'data/countries+states+cities.json', json_encode($json_data));
            $json = file_get_contents(plugin_dir_url( __DIR__ ) . 'data/countries+states+cities.json');
            // echo $json;
            echo $country;
            wp_die();
        }

    }
    new GF_Auto_Countrycity_Field_Ajax;
?>
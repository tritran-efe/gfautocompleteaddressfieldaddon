<?php
    if ( ! class_exists( 'GFForms' ) ) {
        die();
    }
    class GF_Field_Country_City extends GF_Field{
        public $type = 'countrycity';

        public function get_form_editor_field_title() {
            return esc_attr__( 'Auto Address', 'country_cityfieldaddon' );
        }
    
        public function get_form_editor_button() {
            return array(
                'group' => 'advanced_fields',
                'text'  => $this->get_form_editor_field_title(),
            );
        }

        function get_form_editor_field_settings() {
            return array(
                'label_setting',
                'description_setting',
                'input_placeholders_setting',
                'admin_label_setting',
			    'label_placement_setting',
			    'sub_label_placement_setting',
                'input_class_setting',
                'css_class_setting',
                'admin_label_setting',
                'visibility_setting',
                'conditional_logic_field_setting',
                'description_setting',
                'rules_setting',
			    'prepopulate_field_setting',
            );
        }

        public function is_conditional_logic_supported() {
            return true;
        }

        function validate( $value, $form ) {

            // if ( $this->isRequired ) {
            //     $country_Required = rgpost( 'input_'. $form['id'] . '_' . $this->id . '_1' );
            //     $states_Required = rgpost( 'input_'. $form['id'] . '_' . $this->id . '_2' );
            //     $city_Required = rgpost( 'input_'. $form['id'] . '_' . $this->id . '_3' );
            //     if ( empty( $country_Required ) || empty( $states_Required ) || empty( $city_Required ) ) {
            //         $this->failed_validation  = true;
            //         $this->validation_message = empty( $this->errorMessage ) ? __( 'This field is required. Please check again.', 'gravityforms' ) : $this->errorMessage;
            //     }
            // }
        }

        public function get_conditional_logic_event_custom(){
            return "onchange='gf_apply_rules_addon(" . $this->formId . ',' . GFCommon::json_encode( $this->conditionalLogicFields ) . ");'";
        }
        public function get_form_editor_inline_script_on_page_render() {
            $script = sprintf( "function SetDefaultValues_countrycity(field) {field.label = '%s';}", $this->get_form_editor_field_title() ) . PHP_EOL;
            $script .= "jQuery(document).bind('gform_load_field_settings', function (event, field, form) {" .
                       "var inputClass = field.inputClass == undefined ? '' : field.inputClass;" .
                       "jQuery('#input_class_setting').val(inputClass);" .
                       "});" . PHP_EOL;
            $script .= "function SetInputClassSetting(value) {SetFieldProperty('inputClass', value);}" . PHP_EOL;
            return $script;
        }

        
        public function get_field_input( $form, $value = '', $entry = null ) {
            $id              = absint( $this->id );
            $form_id         = absint( $form['id'] );
            $is_entry_detail = $this->is_entry_detail();
            $is_form_editor  = $this->is_form_editor();
            $tabindex      = $this->get_tabindex();
            $field_id = $is_entry_detail || $is_form_editor || $form_id == 0 ? "input_$id" : 'input_' . $form_id . "_$id";

            $country = '';
            $states = '';
            $city  = '';
            $ward = '';

            if ( is_array( $value ) ) {
                $country = esc_attr( RGForms::get( $this->id . '.1', $value ) );
                $states = esc_attr( RGForms::get( $this->id . '.2', $value ) );
                $city  = esc_attr( RGForms::get( $this->id . '.3', $value ) );
                $ward = esc_attr( RGForms::get( $this->id . '.4', $value ) );
            }

            $country_input = GFFormsModel::get_input( $this, $this->id . '.1' );
            $states_input = GFFormsModel::get_input( $this, $this->id . '.2' );
            $city_input = GFFormsModel::get_input( $this, $this->id . '.3' );
            $ward_input = GFFormsModel::get_input( $this, $this->id . '.4' );
            //lable
            $country_sub_label = rgar( $country_input, 'customLabel' ) != '' ? $country_input['customLabel'] : apply_filters( "gform_name_country_{$form_id}", apply_filters( 'gform_name_country', __( 'Country', 'gravityforms' ), $form_id ), $form_id );
            $states_sub_label = rgar( $states_input, 'customLabel' ) != '' ? $states_input['customLabel'] : apply_filters( "gform_name_states_{$form_id}", apply_filters( 'gform_name_states', __( 'States', 'gravityforms' ), $form_id ), $form_id );
            $city_sub_label = rgar( $city_input, 'customLabel' ) != '' ? $city_input['customLabel'] : apply_filters( "gform_name_city_{$form_id}", apply_filters( 'gform_name_city', __( 'City', 'gravityforms' ), $form_id ), $form_id );
            $ward_sub_label = rgar( $ward_input, 'customLabel' ) != '' ? $ward_input['customLabel'] : apply_filters( "gform_name_ward_{$form_id}", apply_filters( 'gform_name_ward', __( 'Ward', 'gravityforms' ), $form_id ), $form_id );
            
            $field = GFFormsModel::get_field( $form, $id );
            // echo "<pre>";print_r($field);echo "</pre>";

            $logic_event           = 'class="gfield_select"';
            $inputClass            = $this->inputClass;
            $custumClass           = $this->customClass;
            $disabled_select       = $is_form_editor ? 'disabled="disabled"' : '';
            $required_attribute    = "";
            $style_input = "custom";

            
            $form_sub_label_placement  = rgar( $form, 'subLabelPlacement' );
		    $field_sub_label_placement = $this->subLabelPlacement;
		    $sub_label_class_attribute = $field_sub_label_placement == 'hidden_label' ? "class='hidden_sub_label'" : '';

            $request = wp_remote_get( plugin_dir_url( __DIR__ ). 'data/countries+states+cities.json');
            $country_rq = wp_remote_retrieve_body($request);
            $country_1 =json_decode($country_rq, TRUE);

            usort($country_1, function ($item1, $item2) {
                return $item1['name'] <=> $item2['name'];
            });

            $country_option = "";
            $states_option = "";
            $city_option = "";
            $ward_option = "";
            $styleward = "display:none;";

            $defaultValue = $field->defaultValue;
            $boolean_defaultValue = false;
            $stylecountry = "";

            foreach($country_1 as $key_country => $val_country){  
                if(empty($uniqueValue)){
                    if($val_country['name'] == $defaultValue){
                        $boolean_defaultValue = true;
                        break;
                    }
                }
            }
            //check States
            if (!function_exists('checkStates'))   {
                function checkStates($val_country){
                    $checkStates = false;
                    if (count($val_country['states']) > 0) {
                        $checkStates = true;
                    }
                    return $checkStates;
                }
            }
            
            //check Ward
            if (!function_exists('checkWard'))   {
                function checkWard($val_country,$field_sub_label_placement1){
                    $checkWard = "display:none;";
                    foreach($val_country['states'] as $val_states){
                        foreach ($val_states['cities'] as $val_city) {
                            if(array_key_exists('ward', $val_city)){
                                if(count($val_city['ward']) > 0){
                                    if ($field_sub_label_placement1 === ''){
                                        $checkWard = "display:table-row;";
                                    }
                                    if ($field_sub_label_placement1 === 'above') {
                                        $checkWard = "display:table-cell;";
                                    }
                                    if ($field_sub_label_placement1 === 'below') {
                                        $checkWard = "display:table-cell;";
                                    }
                                }
                                break;
                            }
                        }
                    }
                    return $checkWard;
                }
              }
            
              if($boolean_defaultValue == true){
                foreach($country_1 as  $val_country){
                    if ($val_country['name'] == $defaultValue) {
                        $country_option .= "<option value='{$val_country['name']}' selected>{$val_country['name']}</option>";
                        foreach($val_country['states'] as  $val_states){
                            $states_option .= "<option value='{$val_states['name']}'>{$val_states['name']}</option>";
                        }
                        $styleward = checkWard($val_country,$field_sub_label_placement);
                        continue;
                    }
                    $country_option .= "<option value='{$val_country['name']}'>{$val_country['name']}</option>";
                }
            }else{
                foreach($country_1 as  $val_country){
                    $country_option .= "<option value='{$val_country['name']}'>{$val_country['name']}</option>";
                }
                foreach($country_1[0]['states'] as  $val_states){
                    $states_option .= "<option value='{$val_states['name']}'>{$val_states['name']}</option>";
                }
                $styleward = checkWard($country_1[0],$field_sub_label_placement);
            }

            $show = "";
            if ($field_sub_label_placement == "above") {
                $country_field = self::get_gfauto_country_field( $country_input, $id, $field_id, $country, $disabled_select, $country_option, $logic_event, $tabindex, $required_attribute);
                $states_field = self::get_gfauto_states_field( $states_input, $id, $form_id, $field_id, $states, $disabled_select, $states_option, $logic_event, $tabindex, $required_attribute);
                $city_field = self::get_gfauto_city_field( $city_input, $id, $field_id, $city, $disabled_select, $city_option, $logic_event, $tabindex, $required_attribute);
                $ward_field = self::get_gfauto_ward_field( $ward_input, $id, $field_id, $ward, $disabled_select, $ward_option, $logic_event, $tabindex, $required_attribute);
                $show = "<div name='country_city_auto_addon' id='{$field_id}' class='{$custumClass}'>
                        <div class='loader' style='display:none;'>
                            <img src= '../wp-content/plugins/gfautocompleteaddressfieldaddon/data/Spin-1s-200px.gif' alt=''>
                        </div>
                            <table id='table_form_setting_above'>
                            <tr id='{$field_id}_1_container'>
                                <td style='{$stylecountry}'><label for='{$field_id}_1' id='{$field_id}_1_label' {$sub_label_class_attribute}><strong>{$country_sub_label} </strong></label></td>
                                <td><label for='{$field_id}_2' id='{$field_id}_2_label' {$sub_label_class_attribute}><strong>$states_sub_label </strong></label></td>
                                <td><label for='{$field_id}_3' id='{$field_id}_3_label' {$sub_label_class_attribute}><strong>$city_sub_label </strong></label></td>
                                <td style='{$styleward}'><label for='{$field_id}_4' id='{$field_id}_4_label' {$sub_label_class_attribute}><strong>{$ward_sub_label} </strong></label></td>
                            </tr>
                            <tr id='{$field_id}_2_container'>
                                <td style='{$stylecountry}'>{$country_field}</td>
                                <td>{$states_field}</td>
                                <td>{$city_field}</td>
                                <td style='{$styleward}'>{$ward_field}</td>
                            </tr>
                            </table>
                        </div>";
            }
            if ($field_sub_label_placement == "below") {
                $country_field = self::get_gfauto_country_field( $country_input, $id, $field_id, $country, $disabled_select, $country_option, $logic_event, $tabindex, $required_attribute);
                $states_field = self::get_gfauto_states_field( $states_input, $id, $form_id, $field_id, $states, $disabled_select, $states_option, $logic_event, $tabindex, $required_attribute);
                $city_field = self::get_gfauto_city_field( $city_input, $id, $field_id, $city, $disabled_select, $city_option, $logic_event, $tabindex, $required_attribute);
                $ward_field = self::get_gfauto_ward_field( $ward_input, $id, $field_id, $ward, $disabled_select, $ward_option, $logic_event, $tabindex, $required_attribute);
                $show = "<div name='country_city_auto_addon' id='{$field_id}' class='{$custumClass}'>
                        <div class='loader' style='display:none;'>
                            <img src= '../wp-content/plugins/gfautocompleteaddressfieldaddon/data/Spin-1s-200px.gif' alt=''>
                        </div>
                            <table id='table_form_setting_below'>
                            <tr id='{$field_id}_1_container'>
                                <td style='{$stylecountry}'>{$country_field}</td>
                                <td>{$states_field}</td>
                                <td>{$city_field}</td>
                                <td style='{$styleward}'>{$ward_field}</td>
                            </tr>
                            <tr id='{$field_id}_2_container' height='1px'>
                                <td style='{$stylecountry}'><label for='{$field_id}_1' id='{$field_id}_1_label' {$sub_label_class_attribute}><strong>{$country_sub_label} </strong></label></td>
                                <td><label for='{$field_id}_2' id='{$field_id}_2_label' {$sub_label_class_attribute}><strong>$states_sub_label </strong></label></td>
                                <td><label for='{$field_id}_3' id='{$field_id}_3_label' {$sub_label_class_attribute}><strong>$city_sub_label </strong></label></td>
                                <td style='{$styleward}'><label for='{$field_id}_4' id='{$field_id}_4_label' {$sub_label_class_attribute}><strong>{$ward_sub_label} </strong></label></td>
                            </tr>
                            </table>
                        </div>";
            }
            if ($field_sub_label_placement == "") {
                $country_field = self::get_gfauto_country_field( $country_input, $id, $field_id, $country, $disabled_select, $country_option, $logic_event, $tabindex, $required_attribute);
                $states_field = self::get_gfauto_states_field( $states_input, $id, $form_id, $field_id, $states, $disabled_select, $states_option, $logic_event, $tabindex, $required_attribute);
                $city_field = self::get_gfauto_city_field( $city_input, $id, $field_id, $city, $disabled_select, $city_option, $logic_event, $tabindex, $required_attribute);
                $ward_field = self::get_gfauto_ward_field( $ward_input, $id, $field_id, $ward, $disabled_select, $ward_option, $logic_event, $tabindex, $required_attribute);
                $show = "<div name='country_city_auto_addon' id='{$field_id}' class='{$custumClass}'>
                        <div class='loader' style='display:none;'>
                            <img src='../wp-content/plugins/gfautocompleteaddressfieldaddon/data/Spin-1s-200px.gif' alt=''>
                        </div>
                            <table id='table_form_setting'>
                            <tr id='{$field_id}_1_container' style='{$stylecountry}'>
                                <td><label for='{$field_id}_1' id='{$field_id}_1_label' {$sub_label_class_attribute}><strong>{$country_sub_label}</strong></label></td>
                                <td>{$country_field}</td>
                            </tr>
                            <tr id='{$field_id}_2_container'>
                                <td><label for='{$field_id}_2' id='{$field_id}_2_label' {$sub_label_class_attribute}><strong>{$states_sub_label} </strong></label></td>
                                <td>{$states_field}</td>
                            </tr>
                            <tr id='{$field_id}_3_container'>
                                <td><label for='{$field_id}_3' id='{$field_id}_3_label' {$sub_label_class_attribute}><strong>{$city_sub_label} </strong></label></td>
                                <td>{$city_field}</td>
                            </tr>
                            <tr id='{$field_id}_4_container' style='{$styleward}'>
                                <td><label for='{$field_id}_4' id='{$field_id}_4_label' {$sub_label_class_attribute}><strong>{$ward_sub_label} </strong></label></td>
                                <td>{$ward_field}</td>
                            </tr>
                            </table>
                        </div>  ";
            }
            return $show;
        }

        public function get_gfauto_country_field($input, $id, $field_id, $country, $disabled_select, $country_option, $logic_event, $tabindex, $required_attribute){
            $placeholder_value_country = GFCommon::get_input_placeholder_value( $input );
            $options_country = "";
            if ($placeholder_value_country) {
                $options_country .= "<option name='country_input_placeholders' value='{$placeholder_value_country}'>{$placeholder_value_country}</option>";
            }
            $options_country .= $country_option;
            $markup = "<select class='{$autocomplete_country}' data-show-subtext='true' data-live-search='true' name='input_{$id}.1' id='{$field_id}_1' {$logic_event} {$disabled_select} {$style_width} {$tabindex} {$required_attribute}>
                              {$options_country}
                          </select>";
            return $markup;
        }

        public function get_gfauto_states_field($input, $id, $form_id, $field_id, $states, $disabled_select, $states_option, $logic_event, $tabindex,  $required_attribute){
            $placeholder_value_states = GFCommon::get_input_placeholder_value( $input );
            $field = GFFormsModel::get_field( $form_id, $id );
            $options_states = "";
            if ($placeholder_value_states) {
                $options_states .= "<option name='states_input_placeholders' value='{$placeholder_value_states}'>{$placeholder_value_states}</option>";
            }else{
                $options_states .= '<option value="No data">Choose the states</option>';
            }
            $options_states .= $states_option;
            $markup = "<select class='{$autocomplete_states}' data-custom-input='{$customInput}' name='input_{$id}.2' id='{$field_id}_2' {$logic_event} {$disabled_select} {$tabindex} {$required_attribute}>
                              {$options_states}
                          </select>";
            return $markup;
        }
    
        public function get_gfauto_city_field($input, $id, $field_id, $city, $disabled_select, $city_option, $logic_event, $tabindex, $required_attribute){
            $placeholder_value_city = GFCommon::get_input_placeholder_value( $input );
            $options_city = "";
            if ($placeholder_value_city) {
                $options_city .= "<option name='city_input_placeholders' value='{$placeholder_value_city}'>{$placeholder_value_city}</option>";
            }else{
                $options_city .= '<option value="No data">Choose the city</option>';
            }
            $options_city .= $city_option;
            $markup = "<select class='{$autocomplete_city}' data-custom-input='{$customInput}' name='input_{$id}.3' id='{$field_id}_3' {$logic_event} {$disabled_select} {$tabindex} {$required_attribute}>
                                {$options_city}
                            </select>";
            ?>
            <?php
            return $markup;
        }

        public function get_gfauto_ward_field($input, $id, $field_id, $ward, $disabled_select, $ward_option, $logic_event, $tabindex,  $required_attribute){
            $placeholder_value_ward = GFCommon::get_input_placeholder_value( $input );
            $options_ward = "";
            if ($placeholder_value_ward) {
                $options_ward .= "<option name='ward_input_placeholders' value='{$placeholder_value_ward}'>{$placeholder_value_ward}</option>";
            }else{
                $options_ward .= '<option value="No data">Choose the ward</option>';
            }
            $options_ward .= $ward_option;
            $markup = "<select class='{$autocomplete_ward}' data-custom-input='{$customInput}' name='input_{$id}.4' id='{$field_id}_4' {$logic_event} {$disabled_select} {$tabindex} {$required_attribute}>
                                {$options_ward}
                            </select>";
            ?>
            <?php
            return $markup;
        }

        public function get_value_entry_detail( $value, $currency = '', $use_text = false, $format = 'html', $media = 'screen' ) {
            if ( is_array( $value ) ) {
                $country_entry  = trim( rgget( $this->id . '.1', $value ) );
                $states_entry  = trim( rgget( $this->id . '.2', $value ) );
                $city_entry = trim( rgget( $this->id . '.3', $value ) );
                $ward_entry = trim( rgget( $this->id . '.4', $value ) );

                $line_break = $format == 'html' ? '<br />' : "\n";
                
                $country_entry_ct = '';
                $states_entry_ct = '<strong>States: </strong>'.$states_entry;
                $city_entry_ct = '<strong>City: </strong>'.$city_entry;
                $ward_entry_ct = '';
                if(!empty($country_entry) ){
                    $country_entry_ct = '<strong>Country: </strong>'.$country_entry .$line_break;
                }
                if(!empty($ward_entry) ){
                    $ward_entry_ct = $line_break .'<strong>Ward: </strong>'.$ward_entry;
                }
                $address = $country_entry_ct . $states_entry_ct . $line_break . $city_entry_ct .  $ward_entry_ct;
                return $address;
            } else {
                return '';
            }
        }
    }
    GF_Fields::register( new GF_Field_Country_City() );
?>